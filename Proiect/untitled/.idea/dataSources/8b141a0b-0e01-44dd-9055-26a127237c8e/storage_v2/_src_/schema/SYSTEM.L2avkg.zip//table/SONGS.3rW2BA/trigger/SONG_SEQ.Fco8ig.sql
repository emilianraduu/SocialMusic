create trigger SONG_SEQ
  before insert
  on SONGS
  for each row
BEGIN
  SELECT song_seq.NEXTVAL
  INTO   :new.id_song
  FROM   dual;
END;
/

