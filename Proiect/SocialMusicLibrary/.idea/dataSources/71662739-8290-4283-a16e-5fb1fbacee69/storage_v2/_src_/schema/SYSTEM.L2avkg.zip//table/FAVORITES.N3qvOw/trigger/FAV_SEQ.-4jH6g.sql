create trigger FAV_SEQ
  before insert
  on FAVORITES
  for each row
BEGIN
  SELECT fav_seq.NEXTVAL
  INTO   :new.id
  FROM   dual;
END;
/

