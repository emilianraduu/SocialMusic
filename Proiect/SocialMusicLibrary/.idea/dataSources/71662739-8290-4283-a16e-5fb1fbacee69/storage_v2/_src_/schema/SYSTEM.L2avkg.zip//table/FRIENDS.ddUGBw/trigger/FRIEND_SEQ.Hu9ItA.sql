create trigger FRIEND_SEQ
  before insert
  on FRIENDS
  for each row
BEGIN
  SELECT friend_seq.NEXTVAL
  INTO   :new.id
  FROM   dual;
END;
/

