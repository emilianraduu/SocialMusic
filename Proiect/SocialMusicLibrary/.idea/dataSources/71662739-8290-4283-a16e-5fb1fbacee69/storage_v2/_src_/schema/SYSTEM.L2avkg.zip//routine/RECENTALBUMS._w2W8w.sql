create FUNCTION recentAlbums 
RETURN number IS 
   total VARCHAR(30); 
BEGIN 
   SELECT * into total 
   FROM (SELECT * FROM albums ORDER BY date) WHERE ROWNUM < 15; 

   RETURN total; 
END;
/

