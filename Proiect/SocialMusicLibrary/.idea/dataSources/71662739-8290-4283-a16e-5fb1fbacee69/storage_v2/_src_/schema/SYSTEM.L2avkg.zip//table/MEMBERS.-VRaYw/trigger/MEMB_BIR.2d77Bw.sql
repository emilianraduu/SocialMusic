create trigger MEMB_BIR
  before insert
  on MEMBERS
  for each row
BEGIN
  SELECT memb_seq.NEXTVAL
  INTO   :new.id_member
  FROM   dual;
END;
/

