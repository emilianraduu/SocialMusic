create trigger ALB_BIR
  before insert
  on ALBUMS
  for each row
BEGIN
  SELECT alb_seq.NEXTVAL
  INTO   :new.id_album
  FROM   dual;
END;
/

